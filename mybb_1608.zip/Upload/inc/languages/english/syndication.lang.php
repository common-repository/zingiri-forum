<?php
/**
 * MyBB 1.6 English Language Pack
 * Copyright 2010 MyBB Group, All Rights Reserved
 * 
 * $Id: syndication.lang.php 5297 2010-12-28 22:01:14Z Tomm $
 */

$l['all_forums'] = "All Forums";
$l['forum'] = "Forum:";
$l['posted_by'] = "Posted By:";
$l['on'] = "on";

?>