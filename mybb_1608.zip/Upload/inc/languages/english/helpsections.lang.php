<?php
/**
 * MyBB 1.6 English Language Pack
 * Copyright 2010 MyBB Group, All Rights Reserved
 * 
 * $Id: helpsections.lang.php 5297 2010-12-28 22:01:14Z Tomm $
 */

// Help Section 1
$l['s1_name'] = "User Maintenance";
$l['s1_desc'] = "Basic instructions for maintaining a forum account.";

// Help Section 2
$l['s2_name'] = "Posting";
$l['s2_desc'] = "Posting, replying, and basic usage of forum.";
?>